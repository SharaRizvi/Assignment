package com.ttn.sling.project.core.service.impl;

import com.ttn.sling.project.core.service.Interface1;
import com.ttn.sling.project.core.service.MyServiceConfiguration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate=true, service = Interface1.class
   // property = {"service.ranking:Integer:7"}
)
@Designate(ocd= MyServiceConfiguration.class)//for configuration
public class ImplementInterface1 implements Interface1 {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public String getSimpleValue() {
        return "\n\n\n\n\nImplementer 1a";
    }

    @Activate
    public void logger(){
        logger.info("Activated method activated");
    }

    @Activate
    public void logger2(){
        logger.info("Activated method 2 activated");
    }

    @Activate
    public void logger3(){
        logger.info("Implementer 1");
    }

    private String configValue;
    @Activate
    public void activate(MyServiceConfiguration configuration) {
        configValue = configuration.configValue();
        logger.info("MySimpleServiceImpl.activate: Config values are configValue:{}",
                configValue);
    }

    @Deactivate
    public void logger4(){
        logger.info("Deactivated method called");
    }

    @Modified
    public void logger5(){
        logger.info("Configuration Modified");
    }
}
