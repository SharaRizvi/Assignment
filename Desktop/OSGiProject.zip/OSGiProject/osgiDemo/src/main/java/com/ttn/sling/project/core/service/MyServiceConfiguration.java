package com.ttn.sling.project.core.service;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name="My Service Configuration", description = "Service Configuration")
public @interface MyServiceConfiguration {
    @AttributeDefinition
    String configValue()  default "ConfigurationClassValue";
}
