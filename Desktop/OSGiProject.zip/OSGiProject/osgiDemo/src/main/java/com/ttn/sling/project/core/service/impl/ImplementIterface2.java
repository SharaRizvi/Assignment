package com.ttn.sling.project.core.service.impl;

import com.ttn.sling.project.core.service.Interface1;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate=true, service = Interface1.class
       //roperty = "service.ranking:Integer:8"
)
public class ImplementIterface2 implements Interface1 {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public String getSimpleValue() {
        return "\n\n\n\n\n\n\nImplementer 2a";
    }

    @Activate
    public  void activate(){
        logger.info("Implementer 2");
    }

}
